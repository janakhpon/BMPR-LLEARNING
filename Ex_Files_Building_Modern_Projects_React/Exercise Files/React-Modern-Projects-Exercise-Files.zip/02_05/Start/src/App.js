import React from 'react';
import './App.css';

const App = () => (
    <div className="App">
        <h1>Hello, World!</h1>
    </div>
);

export default App;